from django.shortcuts import render
from .models import (
    Pessoa, Ocupacao, InstituicaoEnsino, AreaSaber, Curso, Turma, Disciplina,
    Matricula, Avaliacao, Frequencia, Turno, Cidade, Ocorrencia, CursoDisciplina,
    AvaliacaoTipo
)
from django.views.generic import TemplateView


class IndexView(TemplateView):
    template_name = 'index.html'


def gerenciar_pessoas(request):
    # Selecionar também cidade e ocupacao para otimizar (FK)
    pessoas = Pessoa.objects.select_related('cidade', 'ocupacao').all()
    return render(request, 'gerenciar_pessoas.html', {'pessoas': pessoas})


def gerenciar_ocupacao_pessoas(request):
    ocupacoes = Ocupacao.objects.all()
    return render(request, 'gerenciar_ocupacao_pessoas.html', {'ocupacoes': ocupacoes})


def gerenciar_instituicao_ensino(request):
    # Otimizar com cidade FK
    instituicoes = InstituicaoEnsino.objects.select_related('cidade').all()
    return render(request, 'gerenciar_instituicao_ensino.html', {'instituicoes': instituicoes})


def gerenciar_areas_saber(request):
    areas = AreaSaber.objects.all()
    return render(request, 'gerenciar_areas_saber.html', {'areas': areas})


def gerenciar_cursos(request):
    # Otimizar com area_saber e instituicao (FK)
    dados = Curso.objects.select_related('area_saber', 'instituicao').all()
    return render(request, 'gerenciar_cursos.html', {'dados': dados})


def gerenciar_turmas(request):
    dados = Turma.objects.all()
    return render(request, 'gerenciar_turmas.html', {'dados': dados})


def gerenciar_disciplinas(request):
    # Otimizar com area_saber (FK)
    dados = Disciplina.objects.select_related('area_saber').all()
    return render(request, 'gerenciar_disciplinas.html', {'dados': dados})


def gerenciar_matriculas(request):
    # Otimizar com instituicao, curso, pessoa (FK)
    dados = Matricula.objects.select_related('instituicao', 'curso', 'pessoa').all()
    return render(request, 'gerenciar_matriculas.html', {'dados': dados})


def gerenciar_avaliacoes(request):
    # Otimizar com curso, disciplina e tipo (FK)
    avaliacoes = Avaliacao.objects.select_related('curso', 'disciplina', 'tipo').all()
    return render(request, 'gerenciar_avaliacoes.html', {'avaliacoes': avaliacoes})


def gerenciar_frequencia(request):
    # Otimizar com aluno, curso e disciplina (FK)
    frequencias = Frequencia.objects.select_related('aluno', 'curso', 'disciplina').all()
    return render(request, 'gerenciar_frequencia.html', {'frequencias': frequencias})


def gerenciar_turnos(request):
    dados = Turno.objects.all()
    return render(request, 'gerenciar_turnos.html', {'dados': dados})


def gerenciar_cidades(request):
    dados = Cidade.objects.all()
    return render(request, 'gerenciar_cidades.html', {'dados': dados})


def gerenciar_ocorrencias(request):
    # Otimizar com curso, disciplina, pessoa (FK)
    dados = Ocorrencia.objects.select_related('curso', 'disciplina', 'pessoa').all()
    return render(request, 'gerenciar_ocorrencias.html', {'dados': dados})


def gerenciar_disciplinas_por_cursos(request):
    # Otimizar com curso, disciplina e periodo (FK)
    cursos_disciplinas = CursoDisciplina.objects.select_related('curso', 'disciplina', 'periodo').all()
    return render(request, 'gerenciar_disciplinas_por_cursos.html', {'cursos_disciplinas': cursos_disciplinas})


def gerenciar_tipos_avaliacao(request):
    tipos = AvaliacaoTipo.objects.all()
    return render(request, 'gerenciar_tipos_avaliacao.html', {'tipos': tipos})

