from django.contrib import admin
from .models import (
    Cidade, Ocupacao, Pessoa, InstituicaoEnsino, AreaSaber, Curso, Turma,
    Disciplina, AvaliacaoTipo, Periodo, Matricula, CursoDisciplina,
    Avaliacao, Frequencia, Turno, Ocorrencia
)

admin.site.register(Cidade)
admin.site.register(Ocupacao)
admin.site.register(Pessoa)
admin.site.register(InstituicaoEnsino)
admin.site.register(AreaSaber)
admin.site.register(Curso)
admin.site.register(Turma)
admin.site.register(Disciplina)
admin.site.register(AvaliacaoTipo)
admin.site.register(Periodo)
admin.site.register(Matricula)
admin.site.register(CursoDisciplina)
admin.site.register(Avaliacao)
admin.site.register(Frequencia)
admin.site.register(Turno)
admin.site.register(Ocorrencia)
