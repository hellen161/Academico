from django.views import View
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit
from django import forms
from .models import Curso
from .models import Pessoa


class CursoForm(forms.ModelForm):
    class Meta:
        model = Curso
        fields = ['nome', 'carga_horaria_total', 'duracao_meses', 'area_saber', 'instituicao']

    def __init__(self, *args, **kwargs):
        super(CursoForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            'nome',
            'carga_horaria_total',
            'duracao_meses',
            'area_saber',
            'instituicao',
            Submit('submit', 'Salvar')
        )
        
class PessoaForm(forms.ModelForm):
    class Meta:
        model = Pessoa
        fields = ['nome', 'pai', 'mae', 'cpf', 'data_nasc', 'email', 'cidade', 'ocupacao']

    def __init__(self, *args, **kwargs):
        super(PessoaForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            'nome',
            'pai',
            'mae',
            'cpf',
            'data_nasc',
            'email',
            'cidade',
            'ocupacao',
            Submit('submit', 'Salvar')
        )