from django.urls import path
from .views import IndexView


from .views import (
    gerenciar_pessoas,
    gerenciar_ocupacao_pessoas,
    gerenciar_instituicao_ensino,
    gerenciar_areas_saber,
    gerenciar_cursos,
    gerenciar_turmas,
    gerenciar_disciplinas,
    gerenciar_matriculas,
    gerenciar_avaliacoes,
    gerenciar_frequencia,
    gerenciar_turnos,
    gerenciar_cidades,
    gerenciar_ocorrencias,
    gerenciar_disciplinas_por_cursos,
    gerenciar_tipos_avaliacao,
)

urlpatterns = [
    path('pessoas/', gerenciar_pessoas, name='gerenciar_pessoas'),
    path('ocupacoes/', gerenciar_ocupacao_pessoas, name='gerenciar_ocupacao_pessoas'),
    path('instituicoes/', gerenciar_instituicao_ensino, name='gerenciar_instituicao_ensino'),
    path('areas_saber/', gerenciar_areas_saber, name='gerenciar_areas_saber'),
    path('cursos/', gerenciar_cursos, name='gerenciar_cursos'),
    path('turmas/', gerenciar_turmas, name='gerenciar_turmas'),
    path('disciplinas/', gerenciar_disciplinas, name='gerenciar_disciplinas'),
    path('matriculas/', gerenciar_matriculas, name='gerenciar_matriculas'),
    path('avaliacoes/', gerenciar_avaliacoes, name='gerenciar_avaliacoes'),
    path('frequencia/', gerenciar_frequencia, name='gerenciar_frequencia'),
    path('turnos/', gerenciar_turnos, name='gerenciar_turnos'),
    path('cidades/', gerenciar_cidades, name='gerenciar_cidades'),
    path('ocorrencias/', gerenciar_ocorrencias, name='gerenciar_ocorrencias'),
    path('disciplinas_por_cursos/', gerenciar_disciplinas_por_cursos, name='gerenciar_disciplinas_por_cursos'),
    path('tipos_avaliacao/', gerenciar_tipos_avaliacao, name='gerenciar_tipos_avaliacao'),
    
]
